import { Router, type IRouter, type Request, type Response } from "express";
import { isEmploymentFormObjectPath } from "./employmentForms";
import { Readable } from "stream";
import {
  RequestUploadUrlBody,
  RequestUploadUrlResponse,
} from "@workspace/api-zod";
import { ObjectStorageService, ObjectNotFoundError } from "../lib/objectStorage";
import { ObjectPermission } from "../lib/objectAcl";
import { actorStaffFromRequest } from "../lib/actorSession";
import { db } from "@workspace/db";
import { objectUploadsTable, tasksTable, assignmentsTable, inspectorTaskLinksTable, conversationsTable, conversationParticipantsTable, issuesTable, areasTable, staffTable, notificationsTable } from "@workspace/db/schema";
import { and, eq } from "drizzle-orm";
import { randomUUID } from "crypto";
import { canMutateTask } from "../lib/workflowPolicies";
import { canReadSharedInspector } from "../lib/sharedInspectorConversation";

const router: IRouter = Router();
const objectStorageService = new ObjectStorageService();

async function canAccessConversation(conversationId: number, actor: NonNullable<Awaited<ReturnType<typeof actorStaffFromRequest>>>) {
  const [conversation] = await db.select().from(conversationsTable).where(eq(conversationsTable.id, conversationId));
  if (!conversation) return false;
  if (conversation.isGroup) {
    const [participant] = await db.select({ id: conversationParticipantsTable.id }).from(conversationParticipantsTable)
      .where(and(eq(conversationParticipantsTable.conversationId, conversationId), eq(conversationParticipantsTable.staffId, actor.id)));
    return Boolean(participant);
  }
  if (conversation.participantAId === actor.id || conversation.participantBId === actor.id) return true;
  const people = await db.select().from(staffTable);
  return canReadSharedInspector(actor, conversation, people);
}

/**
 * POST /storage/uploads/request-url
 *
 * Request a presigned URL for file upload.
 * The client sends JSON metadata (name, size, contentType) — NOT the file.
 * Then uploads the file directly to the returned presigned URL.
 */
router.post("/storage/uploads/request-url", async (req: Request, res: Response) => {
  const actor = await actorStaffFromRequest(req);
  const parsed = RequestUploadUrlBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Missing or invalid required fields" });
    return;
  }
  if (!actor && parsed.data.purpose !== "application_document") {
    res.status(401).json({ error: "Login session required" });
    return;
  }

  try {
    const { name, size, contentType, purpose, taskId, conversationId, issueId, areaId } = parsed.data;
    const imagePurpose = ["task_before", "task_after", "issue_before", "issue_after", "conversation_attachment", "shared_photo"].includes(purpose);
    if (!["image/jpeg", "image/png", "image/webp", "application/pdf"].includes(contentType) ||
        (imagePurpose && !["image/jpeg", "image/png", "image/webp"].includes(contentType)) ||
        size > 10 * 1024 * 1024 ||
        ((purpose === "task_before" || purpose === "task_after") && !taskId) ||
         (purpose === "conversation_attachment" && !conversationId) ||
         (purpose === "issue_after" && !issueId) ||
         (purpose === "issue_before" && !issueId && !areaId) ||
         (purpose !== "application_document" && !actor)) {
      res.status(400).json({ error: "Invalid upload purpose, target, type, or size" }); return;
    }

    if (taskId) {
      if (!actor) { res.status(401).json({ error: "Login session required" }); return; }
      const [task] = await db.select({
        assignedToId: tasksTable.assignedToId, areaId: tasksTable.areaId, taskDate: tasksTable.taskDate,
      }).from(tasksTable).where(eq(tasksTable.id, taskId));
      if (!task) { res.status(404).json({ error: "Upload target not found" }); return; }
      const [[link], [areaAssignment]] = await Promise.all([
        db.select({ taskId: inspectorTaskLinksTable.taskId }).from(inspectorTaskLinksTable).where(eq(inspectorTaskLinksTable.taskId, taskId)).limit(1),
        db.select({ id: assignmentsTable.id }).from(assignmentsTable).where(and(
          eq(assignmentsTable.staffId, actor.id),
          eq(assignmentsTable.areaId, task.areaId),
          eq(assignmentsTable.assignmentDate, task.taskDate),
        )).limit(1),
      ]);
      if (!canMutateTask(actor, task.assignedToId, Boolean(link), Boolean(areaAssignment))) {
        res.status(403).json({ error: "Upload target access denied" }); return;
      }
    }
    if (conversationId) {
      if (!await canAccessConversation(conversationId, actor!)) { res.status(403).json({ error: "Upload target access denied" }); return; }
    }
    if (issueId) {
      const [issue] = await db.select({ reportedById: issuesTable.reportedById, assignedToId: issuesTable.assignedToId }).from(issuesTable).where(eq(issuesTable.id, issueId));
      if (!issue) { res.status(404).json({ error: "Upload target not found" }); return; }
      if (actor!.role === "staff" && issue.reportedById !== actor!.id && issue.assignedToId !== actor!.id) { res.status(403).json({ error: "Upload target access denied" }); return; }
    }
    if (purpose === "issue_before" && !issueId && areaId) {
      const [area] = await db.select({ id: areasTable.id }).from(areasTable).where(eq(areasTable.id, areaId));
      if (!area) { res.status(404).json({ error: "Upload target not found" }); return; }
    }

    const uploadURL = await objectStorageService.getObjectEntityUploadURL();
    const objectPath = objectStorageService.normalizeObjectEntityPath(uploadURL);
    const applicantToken = purpose === "application_document" ? randomUUID() : null;
    await db.insert(objectUploadsTable).values({ objectPath, ownerStaffId: actor?.id ?? null, purpose, taskId: taskId ?? null, conversationId: conversationId ?? null, issueId: issueId ?? null, areaId: areaId ?? null, applicantToken, mimeType: contentType, sizeBytes: size });

    res.json(
      RequestUploadUrlResponse.parse({
        uploadURL,
        objectPath,
        uploadToken: applicantToken ?? undefined,
        metadata: { name, size, contentType },
      }),
    );
  } catch (error) {
    console.error("Error generating upload URL:", error);
    res.status(500).json({ error: "Failed to generate upload URL" });
  }
});

/**
 * GET /storage/public-objects/*
 *
 * Serve public assets from PUBLIC_OBJECT_SEARCH_PATHS.
 * These are unconditionally public — no authentication or ACL checks.
 * IMPORTANT: Always provide this endpoint when object storage is set up.
 */
router.get("/storage/public-objects/*filePath", async (req: Request, res: Response) => {
  try {
    const raw = req.params.filePath;
    const filePath = Array.isArray(raw) ? raw.join("/") : raw;
    const file = await objectStorageService.searchPublicObject(filePath);
    if (!file) {
      res.status(404).json({ error: "File not found" });
      return;
    }

    const response = await objectStorageService.downloadObject(file);

    res.status(response.status);
    response.headers.forEach((value, key) => res.setHeader(key, value));

    if (response.body) {
      const nodeStream = Readable.fromWeb(response.body as ReadableStream<Uint8Array>);
      nodeStream.pipe(res);
    } else {
      res.end();
    }
  } catch (error) {
    console.error("Error serving public object:", error);
    res.status(500).json({ error: "Failed to serve public object" });
  }
});

/**
 * GET /storage/objects/*
 *
 * Serve object entities from PRIVATE_OBJECT_DIR.
 * These are served from a separate path from /public-objects and can optionally
 * be protected with authentication or ACL checks based on the use case.
 */
router.get("/storage/objects/*path", async (req: Request, res: Response) => {
  try {
    const actor = await actorStaffFromRequest(req);
    const raw = req.params.path;
    const wildcardPath = Array.isArray(raw) ? raw.join("/") : raw;
    const objectPath = `/objects/${wildcardPath}`;
    const blankTemplate = isEmploymentFormObjectPath(objectPath);
    if (!actor) {
      if (!blankTemplate) {
        res.status(401).json({ error: "Login session required" });
        return;
      }
      const file = await objectStorageService.getObjectEntityFile(objectPath);
      const response = await objectStorageService.downloadObject(file);
      res.status(response.status);
      response.headers.forEach((value, key) => res.setHeader(key, value));
      res.setHeader("Cache-Control", "private, no-store");
      if (response.body) {
        Readable.fromWeb(response.body as ReadableStream<Uint8Array>).pipe(res);
      } else {
        res.end();
      }
      return;
    }
    // HR originals, staged bytes and previews must go through the dedicated
    // Admin-only, audited endpoint, even for administrators.
    if (objectPath.startsWith("/objects/hr-identity/")) {
      res.status(403).json({ error: "Use the protected HR document endpoint" }); return;
    }
    const [metadata] = await db.select().from(objectUploadsTable).where(eq(objectUploadsTable.objectPath, objectPath));
    if (metadata?.purpose === "application_document" && actor.role !== "admin") {
      res.status(403).json({ error: "Only administrators may access completed applications" }); return;
    }
    if (metadata?.purpose === "application_document") res.setHeader("Cache-Control", "private, no-store");
    let allowed = actor.role === "admin" || blankTemplate;
    if (metadata) {
      if (metadata.purpose === "conversation_attachment") {
        // Conversation photos are only readable by people authorized to read
        // that exact thread; uploader ownership must not bypass membership.
        allowed = metadata.conversationId !== null && await canAccessConversation(metadata.conversationId, actor);
      } else {
        allowed ||= metadata.ownerStaffId === actor.id;
        if (!allowed && metadata.taskId && (metadata.purpose === "task_before" || metadata.purpose === "task_after")) {
          const [task] = await db.select({
            assignedToId: tasksTable.assignedToId,
            beforeImagePath: tasksTable.beforeImagePath,
            afterImagePath: tasksTable.afterImagePath,
          }).from(tasksTable).where(eq(tasksTable.id, metadata.taskId));
          const isAttachedPhoto = metadata.purpose === "task_before"
            ? task?.beforeImagePath === objectPath
            : task?.afterImagePath === objectPath;
          allowed = Boolean(isAttachedPhoto && (
            task?.assignedToId === actor.id ||
            actor.role === "supervisor" ||
            actor.role === "inspector"
          ));
        }
        if (!allowed && metadata.conversationId) {
          allowed = await canAccessConversation(metadata.conversationId, actor);
        }
        if (!allowed && (metadata.purpose === "issue_before" || metadata.purpose === "issue_after")) {
          const isBeforePhoto = metadata.purpose === "issue_before";
          const [issue] = await db.select({
            id: issuesTable.id,
            reportedById: issuesTable.reportedById,
            assignedToId: issuesTable.assignedToId,
          }).from(issuesTable).where(and(
            isBeforePhoto
              ? eq(issuesTable.beforeImagePath, objectPath)
              : eq(issuesTable.afterImagePath, objectPath),
            metadata.issueId !== null ? eq(issuesTable.id, metadata.issueId) : undefined,
          ));

          if (issue && (actor.role === "supervisor" || actor.role === "inspector" ||
              issue.reportedById === actor.id || issue.assignedToId === actor.id)) {
            allowed = true;
          } else if (issue) {
            const [assignmentNotification] = await db.select({ id: notificationsTable.id })
              .from(notificationsTable)
              .where(and(
              eq(notificationsTable.staffId, actor!.id),
                eq(notificationsTable.issueId, issue.id),
                eq(notificationsTable.type, "issue_assigned"),
              ))
              .limit(1);
            allowed = Boolean(assignmentNotification);
          }
        }
        if (!allowed && metadata.purpose === "shared_photo") {
          allowed = true;
        }
      }
    }
    if (!allowed) { res.status(403).json({ error: "Object access denied" }); return; }
    const objectFile = await objectStorageService.getObjectEntityFile(objectPath);

    // --- Protected route example (uncomment when using replit-auth) ---
    // if (!req.isAuthenticated()) {
    //   res.status(401).json({ error: "Unauthorized" });
    //   return;
    // }
    // const canAccess = await objectStorageService.canAccessObjectEntity({
    //   userId: req.user.id,
    //   objectFile,
    //   requestedPermission: ObjectPermission.READ,
    // });
    // if (!canAccess) {
    //   res.status(403).json({ error: "Forbidden" });
    //   return;
    // }

    const response = await objectStorageService.downloadObject(objectFile);

    res.status(response.status);
    response.headers.forEach((value, key) => res.setHeader(key, value));
    if (isEmploymentFormObjectPath(objectPath) || metadata?.purpose === "application_document") {
      res.setHeader("Cache-Control", "private, no-store");
    }

    if (response.body) {
      const nodeStream = Readable.fromWeb(response.body as ReadableStream<Uint8Array>);
      nodeStream.pipe(res);
    } else {
      res.end();
    }
  } catch (error) {
    console.error("Error serving object:", error);
    if (error instanceof ObjectNotFoundError) {
      res.status(404).json({ error: "Object not found" });
      return;
    }
    res.status(500).json({ error: "Failed to serve object" });
  }
});

export default router;
